export default function() {
  return 42;
};
